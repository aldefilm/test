# /home/pi/aurion/aurion_left.py
import os, time, json, hashlib
import pygame
from aurion_ui import (
    open_fullscreen_on, load_font, make_scanlines, make_tint, make_noise_frames,
    fade_from_black, play_splash_embedded, play_splash_8s,
    find_album_json, load_album, fmt_time
)

SCREEN_INDEX = "0"  # Left HDMI
BLUE  = (150,200,255)
RED   = (220,40,40)
WHITE = (230,230,230)
BLACK = (0,0,0)

BOOKMARKS_PATH = "/homeaurion/config/bookmarks.json"

# ---------- bookmarks ----------
def _load_bookmarks():
    try:
        with open(BOOKMARKS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_bookmarks(data):
    os.makedirs(os.path.dirname(BOOKMARKS_PATH), exist_ok=True)
    with open(BOOKMARKS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def _album_key(meta, album_folder):
    if "album_id" in meta:
        return meta["album_id"]
    return hashlib.sha1(album_folder.encode("utf-8")).hexdigest()[:16]

# ---------- idle (splash → fade → welcome) ----------
def run_idle_until_sd(greeting="Commander"):
    # Open our fullscreen window first (black)
    screen, clock = open_fullscreen_on(SCREEN_INDEX)
    screen.fill((0,0,0)); pygame.display.flip()

    # Try embedded splash (seamless). If cvlc/X11 unavailable, fall back to external.
    try:
        play_splash_embedded(screen, clock, stop_seconds=8)
    except Exception:
        play_splash_8s()

    # Fade in to the idle UI
    fade_from_black(screen, clock, ms=300)

    sw, sh = screen.get_size()
    font = load_font(48)

    full_text = f"Welcome {greeting}"
    renders = [font.render(full_text[:i], True, BLUE) for i in range(len(full_text)+1)]
    frames_per_letter = 2
    blink_frames      = 15

    scan  = make_scanlines((sw, sh))
    tint  = make_tint((sw, sh))
    noise = make_noise_frames((sw, sh))

    frame = 0; letters = 0; blink = True; ni = 0; last_poll = 0.0
    finished_welcome = False

    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                pygame.quit(); return None

        frame += 1
        if letters < len(full_text) and frame % frames_per_letter == 0:
            letters += 1
            if letters == len(full_text):
                finished_welcome = True
        if frame % blink_frames == 0:
            blink = not blink

        # poll SD
        now = time.time()
        if now - last_poll >= 0.5:
            last_poll = now
            jp = find_album_json()
            if jp:
                pygame.quit(); return jp

        # draw
        screen.fill(BLACK)
        t1 = renders[letters]
        c1 = (sw // 2, sh // 2 - 60)
        screen.blit(t1, t1.get_rect(center=c1))

        if finished_welcome and blink:
            t2 = font.render("Insert Cartridge", True, RED)
            c2 = (sw // 2, sh // 2 + 40)
            screen.blit(t2, t2.get_rect(center=c2))

        screen.blit(scan, (0,0))
        screen.blit(noise[ni], (0,0)); ni = (ni+1) % len(noise)
        screen.blit(tint, (0,0))

        pygame.display.flip()
        clock.tick(30)

# ---------- build track list ----------
def pair_titles_with_files(base, main_titles, bonus_titles):
    files = sorted([f for f in os.listdir(base) if f.lower().endswith(".mp3")])
    tracks = []
    for i, title in enumerate(main_titles):
        fn = files[i] if i < len(files) else ""
        tracks.append({"title": title, "filename": fn})
    off = len(main_titles)
    for i, title in enumerate(bonus_titles):
        idx = off + i
        fn = files[idx] if idx < len(files) else ""
        tracks.append({"title": title, "filename": fn})
    return tracks, len(main_titles)

# ---------- album UI ----------
def run_album_ui(json_path):
    data   = load_album(json_path)
    artist = data.get("artist","")
    album  = data.get("album","")
    base   = os.path.dirname(json_path)

    main_titles  = data.get("tracks", [])
    bonus_titles = data.get("bonus",  [])
    tracks, main_count = pair_titles_with_files(base, main_titles, bonus_titles)
    if not tracks: tracks=[{"title":"(No tracks)","filename":""}]; main_count=0

    screen, clock = open_fullscreen_on(SCREEN_INDEX)
    sw, sh = screen.get_size()
    font_big   = load_font(44)
    font_small = load_font(36)
    scan = make_scanlines((sw, sh))
    tint = make_tint((sw, sh), (0,255,200,10))
    noise = make_noise_frames((sw, sh), dots=500, alpha=18)
    ni = 0

    pygame.mixer.init(frequency=44100, channels=2)

    def play_track(i, start_sec=0):
        fn = tracks[i].get("filename","")
        if not fn: return False
        path = os.path.join(base, fn)
        try:
            pygame.mixer.music.load(path)
            if start_sec > 0:
                try: pygame.mixer.music.play(start=start_sec)
                except Exception: pygame.mixer.music.play()
            else:
                pygame.mixer.music.play()
            return True
        except Exception as e:
            print("[aurion] audio load error:", e); return False

    bmarks = _load_bookmarks()
    key    = _album_key(data, base)
    idx = 0; resume_sec = 0
    if key in bmarks:
        idx = min(max(0, bmarks[key].get("track",0)), len(tracks)-1)
        resume_sec = max(0, int(bmarks[key].get("pos",0)))
        print(f"[aurion] Resuming {key} at track {idx+1}, {resume_sec}s")

    play_track(idx, resume_sec)
    paused = False; album_ended = False
    start_wall = time.time() - resume_sec

    def current_elapsed():
        ms = pygame.mixer.music.get_pos()
        return int(ms/1000) if ms >= 0 else int(time.time() - start_wall)

    running=True
    while running:
        for e in pygame.event.get():
            if e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE: running=False
                elif e.key==pygame.K_SPACE:
                    if album_ended and paused and len(tracks)>main_count:
                        idx=main_count; play_track(idx,0)
                        start_wall=time.time(); paused=False; album_ended=False
                    else:
                        if paused:
                            pygame.mixer.music.unpause(); paused=False
                            start_wall=time.time()-current_elapsed()
                        else:
                            pygame.mixer.music.pause(); paused=True
                elif e.key==pygame.K_s:
                    pos=current_elapsed(); bmarks[key]={"track":idx,"pos":pos}
                    _save_bookmarks(bmarks); pygame.mixer.music.stop(); paused=True
                elif e.key==pygame.K_RIGHT and idx<len(tracks)-1:
                    idx+=1; play_track(idx,0); start_wall=time.time(); album_ended=False
                elif e.key==pygame.K_LEFT and idx>0:
                    idx-=1; play_track(idx,0); start_wall=time.time(); album_ended=False

        if not paused and not pygame.mixer.music.get_busy():
            if idx+1 < main_count:
                idx+=1; play_track(idx,0); start_wall=time.time()
            elif idx+1 == main_count:
                if not album_ended:
                    album_ended=True; pygame.mixer.music.stop(); paused=True
            else:
                if idx < len(tracks)-1:
                    idx+=1; play_track(idx,0); start_wall=time.time()

        elapsed=current_elapsed()
        title=tracks[idx].get("title","(untitled)")
        line1=f"{idx+1}. {title}  {fmt_time(elapsed)}"

        screen.fill(BLACK)
        t1=font_big.render(line1,True,BLUE)
        screen.blit(t1,t1.get_rect(center=(sw//2,sh//2-60)))
        t2=font_small.render(album,True,WHITE)
        screen.blit(t2,t2.get_rect(center=(sw//2,sh//2)))
        t3=font_small.render(artist,True,WHITE)
        screen.blit(t3,t3.get_rect(center=(sw//2,sh//2+48)))

        if album_ended and paused and len(tracks)>main_count:
            hint=font_small.render("Main complete — press PLAY for bonus tracks",True,RED)
            screen.blit(hint,hint.get_rect(center=(sw//2,sh//2+110)))

        screen.blit(scan,(0,0))
        screen.blit(noise[ni],(0,0)); ni=(ni+1)%len(noise)
        screen.blit(tint,(0,0))
        pygame.display.flip(); clock.tick(30)

    pos=current_elapsed(); bmarks[key]={"track":idx,"pos":pos}
    _save_bookmarks(bmarks); pygame.mixer.music.stop(); pygame.quit()
    
def run_left_worker(album_q, greeting="Commander"):
    jp = run_idle_until_sd(greeting=greeting)
    if jp:
        try:
            album_q.put(jp, block=False)
        except Exception:
            pass
            
        run_album_ui(jp)
    

if __name__=="__main__":
    run_left_worker(album_q=None, greeting="Commander")
